package katherine.gotovsky;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

	class Dictionary extends Boggle {
		public BinarySearchTree index;
		/**
		 * Prefix is an array of binary search trees where the tree located at
		 * element i in the array contains all substrings of length i at index 0
		 * in the dictionary file. Hence, the word 'catch' is stored in [1] as
		 * 'c', [2] as 'ca', [3] as 'cat', etc. This allows the search function
		 * to abort search paths which can never result in words.
		 */
		public BinarySearchTree[] prefix;
		/**
		 * Constructs a dictionary
		 * 
		 * @param file File to parse
		 * @throws IOException If file can't be read.
		 */
			index = new BinarySearchTree();
			prefix = new BinarySearchTree[MAX_WORD_LENGTH];

			// Initialize prefix BSTs
			for (int i = 0; i < prefix.length; i++) {
				prefix[i] = new BinarySearchTree();
			}

			String word;

			Scanner scanner = new Scanner(filename);
			scanner.useDelimiter("[\\n]"); // Separate tokens using newlines

			// Add words to indexes
			word: while (scanner.hasNext()) {
				// Get word
				word = scanner.next();

				if (word.length() > MAX_WORD_LENGTH) {
					// Word is too long, skip
					continue word;
				}

				// Lowercase
				word = word.toLowerCase();

				// Add word to primary dictionary
				index.add(word);

				// Add word prefixes to prefix dictionaries
				for (int i = MIN_PREFIX_LENGTH; i < prefix.length && i < word.length(); i++) {
					prefix[i].add(word.substring(0, i));
				}
			}
		}
	}

