package katherine.gotovsky;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		String filename = "E:\\JoeyZhong.txt"; //be sure to add 2 backslashes

		try {
			ReadFile file = new ReadFile(filename);

			String[] sw = file.openFile();

			for (int i = 0; i < sw.length; i++) {
				System.out.println(sw[i]);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

}
