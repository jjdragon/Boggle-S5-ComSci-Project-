package katherine.gotovsky;

import java.io.File;
import java.io.IOException;
import java.util.Random;

	public class Boggle {
		public static int DEFAULT_SIZE = 4; // Default dimensions of grid
		public static int MIN_PREFIX_LENGTH = 3; // Smallest number of characters
		// in a prefix tree
		public static int MIN_WORD_LENGTH = 3; // Lowest number of letters in a
		// word.
		public static int MAX_WORD_LENGTH = 64; // Highest number of letters in a
		// match.
		public static int INITIAL_WORD_TARGET_LENGTH = 7; // Reasonable standard
		// for
		// exhaustive search

		private int size; // Dimensions of grid
		private Cell[][] grid; // Boggle grid

		private Random generator = new Random();
		
		/**
		 * Creates a new boggle board of the default dimensions, filled with random
		 * characters.
		 * 
		 */
		public Boggle() {
			generator = new Random();
			size = DEFAULT_SIZE;
			grid = new Cell[size][size];
			for (int i = 0; i < grid.length; i++) {
				for (int j = 0; j < grid[i].length; j++) {
					grid[i][j] = new Cell(randomChar());
				}
			}
		}

		/**
		 * Searches the board for matches in the given Dictionary. Prints matches as
		 * they are found.
		 * 
		 * @param dictionary The dictionary to check against.
		 */
		public BinarySearchTree findWords(Dictionary dictionary) {
			BinarySearchTree matches = new BinarySearchTree();
			StringBuffer charBuffer = new StringBuffer();

			for (int i = 0; i < size; i++) {
				for (int j = 0; j < size; j++) {
					findWords(dictionary, matches, i, j, charBuffer);
				}
			}

			System.out.println(matches); 
			return matches;
		}


		/**
		 * Recursively searches a Cell for words
		 * 
		 * @param dictionary Dictionary of valid words
		 * @param matches Words found in the board
		 * @param i Vertical index of word in board
		 * @param j Horizontal index of word in board
		 * @param charBuffer Characters this method has traversed
		 */
		private void findWords(Dictionary dictionary, BinarySearchTree matches,
				int i, int j, StringBuffer charBuffer) {

			// Whether or not this is a valid beginning to a word
			boolean valid_word_prefix = true;

			// Add this cell to character buffer
			charBuffer.append(grid[i][j].c);

			// Mark cell as visited
			grid[i][j].visited = true;

			// Set word
			String word = new String(charBuffer);

			// Word candidate
			if (charBuffer.length() >= MIN_WORD_LENGTH
					&& charBuffer.length() <= MAX_WORD_LENGTH) {
				// The number of characters we have is within the acceptable range
				// for a word.

				// Check word for word-i-ness.
				if (dictionary.index.find(word)) {
					// This is a word
					if (matches.add(word)) {
						// We haven't seen this word before
						System.out.println(matches.size() + ": " + word);
					}
				}
			}

			// Since we're returning control, this Cell is no longer visited
			grid[i][j].visited = false;
			// Remove Cell from character stack
			charBuffer.deleteCharAt(charBuffer.length() - 1);
		}

		/**
		 * Returns a human-readable representation of the board.
		 */
		public String toString() {
			String str = "|";
			for (int j = 0; j < size * 4 - 1; j++) {
				str = str + '-';
			}
			str = str + "|\n";

			for (int i = 0; i < size; i++) {
				str = str + "| ";
				for (int j = 0; j < size; j++) {
					str = str + grid[i][j].c;
					str = str + " | ";
				}
				str = str + "\n|";
				for (int j = 0; j < size * 4 - 1; j++) {
					str = str + '-';
				}
				str = str + "|\n";
			}
			return str;
		}

		// Main methods

		public static void main(String[] args) throws IOException {
			String filename = "E:\\JoeyZhong.txt"; //be sure to add 2 backslashes
			
				Boggle board = new Boggle();
				// Display board
				System.out.println(board);

				// Get dictionary
				System.out.print("Building dictionary... ");
				long startIndexTime = System.currentTimeMillis();
	
				System.out.println("Done.");
		}


		/**
		 * Returns a random lowercase character from a to z roughly matching the
		 * frequency distribution of english text.
		 */
		private char randomChar() {
			float i = generator.nextInt(1000000);
			i = i / 1000000;
			if (i < .08167) {
				return 'a';
			}
			if (i < .09659) {
				return 'b';
			}
			if (i < .12441) {
				return 'c';
			}
			if (i < .16694) {
				return 'd';
			}
			if (i < .29396) {
				return 'e';
			}
			if (i < .31624) {
				return 'f';
			}
			if (i < .33639) {
				return 'g';
			}
			if (i < .39733) {
				return 'h';
			}
			if (i < .46699) {
				return 'i';
			}
			if (i < .46852) {
				return 'j';
			}
			if (i < .47624) {
				return 'k';
			}
			if (i < .51649) {
				return 'l';
			}
			if (i < .54055) {
				return 'm';
			}
			if (i < .60804) {
				return 'n';
			}
			if (i < .68311) {
				return 'o';
			}
			if (i < .70240) {
				return 'p';
			}
			if (i < .70335) {
				return 'q';
			}
			if (i < .76322) {
				return 'r';
			}
			if (i < .82649) {
				return 's';
			}
			if (i < .91705) {
				return 't';
			}
			if (i < .94463) {
				return 'u';
			}
			if (i < .95441) {
				return 'v';
			}
			if (i < .97801) {
				return 'w';
			}
			if (i < .97951) {
				return 'x';
			}
			if (i < .99925) {
				return 'y';
			}
			if (i < 1) {
				return 'z';
			} else {
				// Failsafe
				return 'e';
			}
		}
}
