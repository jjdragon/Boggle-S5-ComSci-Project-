package katherine.gotovsky;

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

public class ReadFile {
	private String path;

	public ReadFile(String filename) {
		path = filename;
	}

	public String[] openFile() throws IOException {
		FileReader fr = new FileReader(path);
		BufferedReader br = new BufferedReader(fr);

		int numberOfLines = readLines();
		String[] textData = new String[numberOfLines];

		for (int i = 0; i < numberOfLines; i++) {
			textData[i] = br.readLine();

		}
		br.close();
		return textData;
	}

	int readLines() throws IOException {
		FileReader file = new FileReader(path);
		BufferedReader br = new BufferedReader(file);

		String line;
		int numberOfLines = 0;

		while ((line = br.readLine()) != null) {
			numberOfLines++;
		}
		br.close();
		return numberOfLines;
	}

}
