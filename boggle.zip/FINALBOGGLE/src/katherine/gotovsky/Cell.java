package katherine.gotovsky;

public class Cell {
	boolean visited;
		char c;

		public Cell(char c) {
			this.c = c;
			visited = false;
		}

		public String toString() {
			return Character.toString(c);
	}
}
